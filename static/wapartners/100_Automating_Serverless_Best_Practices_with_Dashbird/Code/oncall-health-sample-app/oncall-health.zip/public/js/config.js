window._config = {
    cognito: {
        userPoolId: 'eu-west-1_PPkynf3wh', // e.g. eu-east-2_uXboG5pAb
        userPoolClientId: '16kjssnfp8bm7v6ugksic72rl0', // e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region: 'eu-west-1' // e.g. us-east-2
    },
    api: {
        invokeUrl: '' // e.g. https://rc7nyt4tql.execute-api.us-west-2.amazonaws.com/prod,
    }
};
