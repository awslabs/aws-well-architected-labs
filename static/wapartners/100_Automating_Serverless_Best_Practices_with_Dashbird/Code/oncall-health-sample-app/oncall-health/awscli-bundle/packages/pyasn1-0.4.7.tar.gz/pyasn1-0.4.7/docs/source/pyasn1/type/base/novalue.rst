.. _type.base.NoValue:

NoValue sentinel
----------------

.. autoclass:: pyasn1.type.base.NoValue()
